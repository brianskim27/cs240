#ifndef __IS_ZANY__
#define __IS_ZANY__

#include<string>
#include<iostream>

bool isZany(int a);
bool isZany(std::string a);

#endif
