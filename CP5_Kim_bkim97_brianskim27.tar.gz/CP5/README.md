# CP5

waitlist:
- implemented using maxheap of students
- students are searched using searchStudent, which implements an unordered map to store all students' bnumbers and their respective index within the maxheap