#include <iostream>
#include <stdlib.h>

using namespace std;

class Roster {
	public:
		Roster();
		void show();
	private:
		int count = 0;
};
