#include <stdlib.h>
#include <iostream>
#include "Roster.h"

using namespace std;

Roster::Roster() {
	int count = 0;
}

void Roster::show() {
}
